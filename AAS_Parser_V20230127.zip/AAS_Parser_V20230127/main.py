#! /usr/bin/env python3
import sys #line:3
sys .path .insert (0 ,".")#line:4
sys .path .insert (1 ,"..")#line:5
import os #line:7
import argparse #line:8
import xmlschema #line:9
import asyncio #line:10
import xmltodict #line:11
import json #line:12
import xml .etree .ElementTree as ET #line:14
from asyncua import ua ,Server #line:16
from asyncua .common .instantiate_util import instantiate #line:17
from asyncua .common .xmlexporter import XmlExporter #line:18
class AAS2OPCUA :#line:21
    def __init__ (O0000OOO0OOO0OOOO ,O000OO000O00O000O ):#line:22
        O0000OOO0OOO0OOOO .aas_file =O000OO000O00O000O #line:25
        O0000OOO0OOO0OOOO .opcua_file ='generated/nodeset.xml'#line:26
        O0000OOO0OOO0OOOO .aas_schema ='AAS.xsd'#line:27
        O0000OOO0OOO0OOOO .end_point ='opc.tcp://0.0.0.0:4840/freeopcua/server/'#line:29
        O0000OOO0OOO0OOOO .doc =None #line:31
        O0000OOO0OOO0OOOO .root =None #line:32
        O0000OOO0OOO0OOOO .shells =None #line:33
        O0000OOO0OOO0OOOO .assets =None #line:34
        O0000OOO0OOO0OOOO .submodels =None #line:35
        O0000OOO0OOO0OOOO .descriptions =None #line:36
        O0000OOO0OOO0OOOO .server =None #line:38
        O0000OOO0OOO0OOOO .shell_info_list =[]#line:40
        O0000OOO0OOO0OOOO .sm_info_list =[]#line:41
        O0000OOO0OOO0OOOO .node_list =[]#line:42
        O0000OOO0OOO0OOOO .aas_ref_list =[]#line:43
        O0000OOO0OOO0OOOO .aasvar_list =[]#line:44
    async def create_opcua_server (O0OO0OOOOO00OO0O0 ):#line:46
        print ('>>> create_opcua_server()')#line:47
        O0OO0OOOOO00OO0O0 .server =Server ()#line:48
        await O0OO0OOOOO00OO0O0 .server .init ()#line:49
        O0OO0OOOOO00OO0O0 .server .set_endpoint (O0OO0OOOOO00OO0O0 .end_point )#line:50
        return True #line:52
    async def export_opcua_model (O0O0OOO0O0OOOOOOO ):#line:55
        print ('>>> export_opcua_model()')#line:56
        O0OO00O0O0O000O0O =XmlExporter (O0O0OOO0O0OOOOOOO .server )#line:57
        await O0OO00O0O0O000O0O .build_etree (O0O0OOO0O0OOOOOOO .node_list )#line:58
        await O0OO00O0O0O000O0O .write_xml (O0O0OOO0O0OOOOOOO .opcua_file )#line:59
        return True #line:61
    async def write_engineering_csv (OO00OOOO00OOO00OO ):#line:64
     print ('>>> write_engineering_csv()')#line:66
     with open ('./generated/engineering.csv',mode ='wt',encoding ='utf-8')as OOO0OOOO00O0OOOOO :#line:68
            for OO0OO00OOO0OO00O0 in OO00OOOO00OOO00OO .aasvar_list :#line:70
                if ''in OO0OO00OOO0OO00O0 :#line:71
                     OOO0OOOO00O0OOOOO .write (OO0OO00OOO0OO00O0 +', , , , 100, -1\n')#line:75
                else :#line:76
                     O0000O00000OO00O0 =20220209 #line:77
    async def load_aas (O000O0O000OO00000 ):#line:81
        if not os .path .exists (O000O0O000OO00000 .aas_file ):#line:84
            print ('%s does not exist!'%(O000O0O000OO00000 .aas_file ))#line:85
            return False #line:86
        '''
        aas_xsd = xmlschema.XMLSchema(self.aas_schema)
        if aas_xsd.is_valid(self.aas_file) == False:
            print('aas[%s] has invalide schema format' % (self.aas_file))
            return False
        '''#line:93
        O000O0O000OO00000 .doc =ET .parse (O000O0O000OO00000 .aas_file )#line:95
        O000O0O000OO00000 .root =O000O0O000OO00000 .doc .getroot ()#line:96
        for O0OOO0000O00O0000 in O000O0O000OO00000 .root :#line:97
            if O0OOO0000O00O0000 .tag .endswith ('assetAdministrationShells'):#line:98
                O000O0O000OO00000 .shells =O0OOO0000O00O0000 #line:99
            elif O0OOO0000O00O0000 .tag .endswith ('assets'):#line:101
                O000O0O000OO00000 .assets =O0OOO0000O00O0000 #line:102
            elif O0OOO0000O00O0000 .tag .endswith ('submodels'):#line:104
                O000O0O000OO00000 .submodels =O0OOO0000O00O0000 #line:105
            elif O0OOO0000O00O0000 .tag .endswith ('conceptDescriptions'):#line:107
                O000O0O000OO00000 .descriptions =None #line:108
        return True #line:110
    async def add_opcua_object (O00O00O0O00O00OOO ,OOO0OO0OO000O0O0O ,O000O00O0OOO0OOO0 ,O0OO00000OO0OOOOO ,O00OOOO000OO00OO0 ,OO00O0OOOO000OOO0 ):#line:113
        if OO00O0OOOO000OOO0 ==1 :#line:114
            return None #line:115
        OO0OOOO0O0O0OO0O0 =None #line:117
        if OOO0OO0OO000O0O0O ==None :#line:119
            OO0OOOO0O0O0OO0O0 =await O00O00O0O00O00OOO .server .nodes .objects .add_object ("ns=%d;s=%s"%(O000O00O0OOO0OOO0 ,O0OO00000OO0OOOOO ),O00OOOO000OO00OO0 )#line:120
        else :#line:121
            OO0OOOO0O0O0OO0O0 =await OOO0OO0OO000O0O0O .add_object ("ns=%d;s=%s"%(O000O00O0OOO0OOO0 ,O0OO00000OO0OOOOO ),O00OOOO000OO00OO0 )#line:122
        O00O00O0O00O00OOO .node_list .append (OO0OOOO0O0O0OO0O0 )#line:124
        return OO0OOOO0O0O0OO0O0 #line:125
    async def add_opcua_variable (O0O00O00000OO0OOO ,O00OO0OOOO0O00O00 ,OOO0OO0O0OOOO000O ,O00OOO0O0OOO0OOO0 ,OOOO00OO000OOOOOO ,OO00O000OOO00O0O0 ,OOO00O0O0000OOOO0 ,O00O0OO0OOOO00000 ):#line:127
        if O00O0OO0OOOO00000 ==1 :#line:128
            return None #line:129
        O0O00000O00OOOO0O =None #line:131
        if O00OO0OOOO0O00O00 ==None :#line:133
            return None #line:134
        OO0OO000O0O00OO0O =None #line:136
        OOOO00OOO00OOO0O0 =None #line:137
        if OO00O000OOO00O0O0 .lower ()=='string'or OO00O000OOO00O0O0 .lower ()=='String':#line:139
            OOOO00OOO00OOO0O0 =ua .NodeId (ua .ObjectIds .String )#line:140
            OO0OO000O0O00OO0O =ua .VariantType .String #line:141
        elif OO00O000OOO00O0O0 .lower ()=='langstring':#line:142
            OOOO00OOO00OOO0O0 =ua .NodeId (ua .ObjectIds .QualifiedName )#line:143
            OO0OO000O0O00OO0O =ua .VariantType .QualifiedName #line:144
        elif OO00O000OOO00O0O0 .lower ()=='datetime'or OO00O000OOO00O0O0 .lower ()=='date'or OO00O000OOO00O0O0 .lower ()=='durationstring':#line:145
            OOOO00OOO00OOO0O0 =ua .NodeId (ua .ObjectIds .DateTime )#line:146
            OO0OO000O0O00OO0O =ua .VariantType .DateTime #line:147
        elif OO00O000OOO00O0O0 .lower ()=='float'or OO00O000OOO00O0O0 .lower ()=='Float':#line:148
            OOOO00OOO00OOO0O0 =ua .NodeId (ua .ObjectIds .Float )#line:149
            OO0OO000O0O00OO0O =ua .VariantType .Float #line:150
        elif OO00O000OOO00O0O0 .lower ()=='double'or OO00O000OOO00O0O0 .lower ()=='Double':#line:151
            OOOO00OOO00OOO0O0 =ua .NodeId (ua .ObjectIds .Double )#line:152
            OO0OO000O0O00OO0O =ua .VariantType .Double #line:153
        elif OO00O000OOO00O0O0 .lower ()=='boolean'or OO00O000OOO00O0O0 .lower ()=='Boolean':#line:154
            OOOO00OOO00OOO0O0 =ua .NodeId (ua .ObjectIds .Boolean )#line:155
            OO0OO000O0O00OO0O =ua .VariantType .Boolean #line:156
        elif OO00O000OOO00O0O0 .lower ()=='decimal':#line:157
            OOOO00OOO00OOO0O0 =ua .NodeId (ua .ObjectIds .UInt64 )#line:159
            OO0OO000O0O00OO0O =ua .VariantType .UInt64 #line:160
        elif OO00O000OOO00O0O0 .lower ()=='integer'or OO00O000OOO00O0O0 .lower ()=='int'or OO00O000OOO00O0O0 .lower ()=='negativeinteger'or OO00O000OOO00O0O0 .lower ()=='nonpositiveinteger'or OO00O000OOO00O0O0 .lower ()=='long':#line:161
            OOOO00OOO00OOO0O0 =ua .NodeId (ua .ObjectIds .Int32 )#line:162
            OO0OO000O0O00OO0O =ua .VariantType .Int32 #line:163
        elif OO00O000OOO00O0O0 .lower ()=='long'or OO00O000OOO00O0O0 .lower ()=='Long':#line:164
            OOOO00OOO00OOO0O0 =ua .NodeId (ua .ObjectIds .Int64 )#line:165
            OO0OO000O0O00OO0O =ua .VariantType .Int64 #line:166
        elif OO00O000OOO00O0O0 .lower ()=='unsignedlong':#line:167
            OOOO00OOO00OOO0O0 =ua .NodeId (ua .ObjectIds .UInt64 )#line:168
            OO0OO000O0O00OO0O =ua .VariantType .UInt64 #line:169
        elif OO00O000OOO00O0O0 .lower ()=='short':#line:170
            OOOO00OOO00OOO0O0 =ua .NodeId (ua .ObjectIds .Int16 )#line:171
            OO0OO000O0O00OO0O =ua .VariantType .Int16 #line:172
        elif OO00O000OOO00O0O0 .lower ()=='byte'or OO00O000OOO00O0O0 .lower ()=='unsignedbyte'or OO00O000OOO00O0O0 .lower ()=='Byte':#line:173
            OOOO00OOO00OOO0O0 =ua .NodeId (ua .ObjectIds .Byte )#line:174
            OO0OO000O0O00OO0O =ua .VariantType .Byte #line:175
        elif OO00O000OOO00O0O0 .lower ()=='nonnegativeinteger'or OO00O000OOO00O0O0 .lower ()=='positiveinteger':#line:176
            OOOO00OOO00OOO0O0 =ua .NodeId (ua .ObjectIds .UInt32 )#line:177
            OO0OO000O0O00OO0O =ua .VariantType .UInt32 #line:178
        elif OO00O000OOO00O0O0 .lower ()=='unsignedshort':#line:179
            OOOO00OOO00OOO0O0 =ua .NodeId (ua .ObjectIds .UInt16 )#line:180
            OO0OO000O0O00OO0O =ua .VariantType .UInt16 #line:181
        elif OO00O000OOO00O0O0 .lower ()=='uint16'or OO00O000OOO00O0O0 .lower ()=='UInt16':#line:182
            OOOO00OOO00OOO0O0 =ua .NodeId (ua .ObjectIds .UInt16 )#line:183
            OO0OO000O0O00OO0O =ua .VariantType .UInt16 #line:184
        elif OO00O000OOO00O0O0 .lower ()=='uint32'or OO00O000OOO00O0O0 .lower ()=='UInt32':#line:185
            OOOO00OOO00OOO0O0 =ua .NodeId (ua .ObjectIds .UInt32 )#line:186
            OO0OO000O0O00OO0O =ua .VariantType .UInt32 #line:187
        elif OO00O000OOO00O0O0 .lower ()=='uint64'or OO00O000OOO00O0O0 .lower ()=='UInt64':#line:188
            OOOO00OOO00OOO0O0 =ua .NodeId (ua .ObjectIds .UInt64 )#line:189
            OO0OO000O0O00OO0O =ua .VariantType .UInt64 #line:190
        else :#line:192
            print ('error: unsupported data-type for property: '+O00OOO0O0OOO0OOO0 )#line:193
        print ("ns = "+str (OOO0OO0O0OOOO000O -1 )+" tagname = "+O00OOO0O0OOO0OOO0 )#line:194
        O0O00000O00OOOO0O =await O00OO0OOOO0O00O00 .add_variable ("ns=%d;s=%s"%(OOO0OO0O0OOOO000O ,O00OOO0O0OOO0OOO0 ),OOOO00OO000OOOOOO ,OOO00O0O0000OOOO0 ,OO0OO000O0O00OO0O ,OOOO00OOO00OOO0O0 )#line:195
        O0O00O00000OO0OOO .node_list .append (O0O00000O00OOOO0O )#line:196
        return O0O00000O00OOOO0O #line:197
    async def parse_reference (OOO0OO0000O00000O ,O00OOOO0OO00O0OOO ,O0O000OO0O0OO00OO ,O0OOO0O000O00OO00 ,O0O0O0O0O0OO00OOO ,OO00O0OOO0O0O0000 ):#line:201
        OOO0O0OO0OOO0OOOO ={}#line:202
        for O0OOOOOOOOO0O00OO in O0O000OO0O0OO00OO :#line:203
            if O0OOOOOOOOO0O00OO .tag .endswith ('idShort'):#line:204
                OOO0O0OO0OOO0OOOO ['idShort']=O0OOOOOOOOO0O00OO .text #line:205
            elif O0OOOOOOOOO0O00OO .tag .endswith ('value'):#line:206
                for O0OO0OOO0000000O0 in O0OOOOOOOOO0O00OO :#line:207
                    if O0OO0OOO0000000O0 .tag .endswith ('keys'):#line:208
                        for O0O0O0OOOOO0O00O0 in O0OO0OOO0000000O0 :#line:209
                            if O0O0O0OOOOO0O00O0 .tag .endswith ('key'):#line:210
                                if O0O0O0OOOOO0O00O0 .attrib ['type']=='AssetAdministrationShell':#line:211
                                    OOO0O0OO0OOO0OOOO ['target']=O0O0O0OOOOO0O00O0 .text #line:212
        if 'idShort'in OOO0O0OO0OOO0OOOO and 'target'in OOO0O0OO0OOO0OOOO :#line:214
            if OO00O0OOO0O0O0000 ==1 :#line:217
                OOO0O0OO0OOO0OOOO ['aas_identification']=O00OOOO0OO00O0OOO ['identification']#line:218
                OOO0O0OO0OOO0OOOO ['parent_tag']=O0OOO0O000O00OO00 #line:219
                OOO0OO0000O00000O .aas_ref_list .append (OOO0O0OO0OOO0OOOO )#line:220
    async def parse_property (O0OO0O0000O0O000O ,OO0OO0000OO000000 ,O0000OO0OOOOOO000 ,O0O0OOO000000000O ,O0OOOOOO00000OOOO ,OOO00OO0OO0O000O0 ):#line:224
        OO000OOOOOOOOOO0O ={}#line:225
        for OOOO000OO000O00O0 in O0000OO0OOOOOO000 :#line:226
            if OOOO000OO000O00O0 .tag .endswith ('idShort'):#line:227
                OO000OOOOOOOOOO0O ['idShort']=OOOO000OO000O00O0 .text #line:228
            elif OOOO000OO000O00O0 .tag .endswith ('valueType'):#line:229
                OO000OOOOOOOOOO0O ['valueType']=OOOO000OO000O00O0 .text #line:230
            elif OOOO000OO000O00O0 .tag .endswith ('value'):#line:231
                OO000OOOOOOOOOO0O ['value']=OOOO000OO000O00O0 .text #line:232
        if 'idShort'in OO000OOOOOOOOOO0O and 'valueType'in OO000OOOOOOOOOO0O :#line:234
            OO0O00OOO0OOOO0O0 =OO0OO0000OO000000 ['ns_index']#line:236
            O00OOOOOOO00O000O =O0O0OOO000000000O +'.'+OO000OOOOOOOOOO0O ['idShort']#line:237
            O0O0OOOO00O000OOO ='%d:%s'%(OO0O00OOO0OOOO0O0 ,OO000OOOOOOOOOO0O ['idShort'])#line:238
            await O0OO0O0000O0O000O .add_opcua_variable (O0OOOOOO00000OOOO ,OO0O00OOO0OOOO0O0 ,O00OOOOOOO00O000O ,O0O0OOOO00O000OOO ,OO000OOOOOOOOOO0O ['valueType'],OO000OOOOOOOOOO0O ['value'],OOO00OO0OO0O000O0 )#line:239
            if OOO00OO0OO0O000O0 ==0 :#line:240
                O0OO0O0000O0O000O .aasvar_list .append ("ns=%d;s=%s"%(OO0O00OOO0OOOO0O0 -1 ,O00OOOOOOO00O000O ))#line:241
    async def parse_collection (O0OO00OO0000OOOOO ,O0000O00O00000O00 ,OO00O00OO0O00OOOO ,O0000O0O0OO000O00 ,O00O0O00000O0OOO0 ,O0OO0O0O00OO000OO ):#line:244
        OO00OO0O00000O000 ={}#line:245
        for OOOOO0O0O0OOO0OOO in OO00O00OO0O00OOOO :#line:246
            if OOOOO0O0O0OOO0OOO .tag .endswith ('idShort'):#line:247
                OO00OO0O00000O000 ['idShort']=OOOOO0O0O0OOO0OOO .text #line:248
        if 'idShort'in OO00OO0O00000O000 :#line:250
            O000OO00O00O00O00 =O0000O00O00000O00 ['ns_index']#line:253
            OO000OOO0O0000OO0 =O0000O0O0OO000O00 +'.'+OO00OO0O00000O000 ['idShort']#line:254
            O0O0O000000O0OO0O ='%d:%s'%(O000OO00O00O00O00 ,OO00OO0O00000O000 ['idShort'])#line:255
            O00O00000O0O0OO00 =await O0OO00OO0000OOOOO .add_opcua_object (O00O0O00000O0OOO0 ,O000OO00O00O00O00 ,OO000OOO0O0000OO0 ,O0O0O000000O0OO0O ,O0OO0O0O00OO000OO )#line:256
            for OOOOO0O0O0OOO0OOO in OO00O00OO0O00OOOO :#line:258
                if OOOOO0O0O0OOO0OOO .tag .endswith ('value'):#line:259
                    for O0OOO0O0OOOO000O0 in OOOOO0O0O0OOO0OOO :#line:260
                        if O0OOO0O0OOOO000O0 .tag .endswith ('submodelElement'):#line:261
                            for O00O00OO00OO00000 in O0OOO0O0OOOO000O0 :#line:262
                                if O00O00OO00OO00000 .tag .endswith ('submodelElementCollection'):#line:263
                                    await O0OO00OO0000OOOOO .parse_collection (O0000O00O00000O00 ,O00O00OO00OO00000 ,OO000OOO0O0000OO0 ,O00O00000O0O0OO00 ,O0OO0O0O00OO000OO )#line:264
                                elif O00O00OO00OO00000 .tag .endswith ('property'):#line:265
                                    await O0OO00OO0000OOOOO .parse_property (O0000O00O00000O00 ,O00O00OO00OO00000 ,OO000OOO0O0000OO0 ,O00O00000O0O0OO00 ,O0OO0O0O00OO000OO )#line:266
                                elif O00O00OO00OO00000 .tag .endswith ('referenceElement'):#line:267
                                    await O0OO00OO0000OOOOO .parse_reference (O0000O00O00000O00 ,O00O00OO00OO00000 ,OO000OOO0O0000OO0 ,O00O00000O0O0OO00 ,O0OO0O0O00OO000OO )#line:268
    async def parse_sm_elements (O00O00O0OOO0O0O00 ,OOOO00O0O000O00OO ,OO000O000O0OOO0O0 ,O00000OO00OOOOOO0 ,O0OO00O000O0O0O0O ,OOOOO00O0OO0OOOO0 ):#line:271
        for OO0O0OOO00OOO0O0O in O00000OO00OOOOOO0 :#line:272
            if OO0O0OOO00OOO0O0O .tag .endswith ('submodelElement'):#line:273
                for OO0O000O000000000 in OO0O0OOO00OOO0O0O :#line:275
                    if OO0O000O000000000 .tag .endswith ('submodelElementCollection'):#line:276
                        await O00O00O0OOO0O0O00 .parse_collection (OO000O000O0OOO0O0 ,OO0O000O000000000 ,O0OO00O000O0O0O0O ,OOOO00O0O000O00OO ,OOOOO00O0OO0OOOO0 )#line:277
                    elif OO0O000O000000000 .tag .endswith ('property'):#line:278
                        await O00O00O0OOO0O0O00 .parse_property (OO000O000O0OOO0O0 ,OO0O000O000000000 ,O0OO00O000O0O0O0O ,OOOO00O0O000O00OO ,OOOOO00O0OO0OOOO0 )#line:279
                    elif OO0O000O000000000 .tag .endswith ('referenceElement'):#line:280
                        await O00O00O0OOO0O0O00 .parse_reference (OO000O000O0OOO0O0 ,OO0O000O000000000 ,O0OO00O000O0O0O0O ,OOOO00O0O000O00OO ,OOOOO00O0OO0OOOO0 )#line:281
    async def parse_sm (OO0OO000O00O000O0 ,O0OO0OO0OO0O0O0O0 ,OO0O0OOO0O0O00OO0 ,O000000O0O000OO0O ,O0000000OO0O0OO00 ,O0000OO0OO00O00OO ):#line:284
        OOOO00OO00OOOO0OO ={}#line:294
        OOOO00OO00OOOO0OO ['aas']=OO0O0OOO0O0O00OO0 #line:295
        for OOO000O00OO0O00OO in O000000O0O000OO0O :#line:297
            if OOO000O00OO0O00OO .tag .endswith ('identification'):#line:298
                OOOO00OO00OOOO0OO ['identification']=OOO000O00OO0O00OO .text #line:299
            elif OOO000O00OO0O00OO .tag .endswith ('idShort'):#line:300
                OOOO00OO00OOOO0OO ['idShort']=OOO000O00OO0O00OO .text #line:301
                OOOO00OO00OOOO0OO ['tagName']=OO0O0OOO0O0O00OO0 ['idShort']+'.'+OOOO00OO00OOOO0OO ['idShort']#line:302
        if 'identification'in OOOO00OO00OOOO0OO and 'idShort'in OOOO00OO00OOOO0OO :#line:305
            O0O0OOOOO0O0O000O =OO0O0OOO0O0O00OO0 ['ns_index']#line:306
            OO0000OOOOOO0O0O0 =O0000000OO0O0OO00 +'.'+OOOO00OO00OOOO0OO ['idShort']#line:307
            O0O0OO0OO000OO0OO ='%d:%s'%(O0O0OOOOO0O0O000O ,OOOO00OO00OOOO0OO ['idShort'])#line:308
            OOOO00OO00OOOO0OO ['object_sm']=await OO0OO000O00O000O0 .add_opcua_object (O0OO0OO0OO0O0O0O0 ,O0O0OOOOO0O0O000O ,OO0000OOOOOO0O0O0 ,O0O0OO0OO000OO0OO ,O0000OO0OO00O00OO )#line:309
            for OO0O000OOO0000O0O in O000000O0O000OO0O :#line:315
                if OO0O000OOO0000O0O .tag .endswith ('submodelElements'):#line:316
                    await OO0OO000O00O000O0 .parse_sm_elements (OOOO00OO00OOOO0OO ['object_sm'],OO0O0OOO0O0O00OO0 ,OO0O000OOO0000O0O ,OO0000OOOOOO0O0O0 ,O0000OO0OO00O00OO )#line:318
        return True #line:320
    async def parse_sm_refs (OO0000O00000OOO00 ,OO0O000OOOOOOO0OO ,OO0O00OO0OOOO0O00 ,OOOOO00OO00OO000O ):#line:323
        OO0O000OOOOOOO0OO ['sm_id_list']=[]#line:325
        for O0O00000OOOO00OOO in OO0O00OO0OOOO0O00 :#line:327
            OO0O000OOOOOOO0OO ['sm_list']=[]#line:328
            for OO0OO0OO0OOOO0O0O in O0O00000OOOO00OOO :#line:329
                if OO0OO0OO0OOOO0O0O .tag .endswith ('keys'):#line:330
                    for OOO0OO0OOOO0O0OOO in OO0OO0OO0OOOO0O0O :#line:331
                        OO0O000OOOOOOO0OO ['sm_id_list'].append (OOO0OO0OOOO0O0OOO .text )#line:332
    async def parse_aas (O0OOO0O0OO00O0OOO ,OOOOOO0O0000OOOOO ):#line:335
        if O0OOO0O0OO00O0OOO .shells ==None :#line:338
            return False #line:339
        del O0OOO0O0OO00O0OOO .shell_info_list [:]#line:341
        del O0OOO0O0OO00O0OOO .sm_info_list [:]#line:342
        del O0OOO0O0OO00O0OOO .node_list [:]#line:343
        del O0OOO0O0OO00O0OOO .aasvar_list [:]#line:344
        O0O000OO0O0000OO0 =await O0OOO0O0OO00O0OOO .server .register_namespace ('urn:open62541.server.application')#line:346
        await O0OOO0O0OO00O0OOO .add_opcua_object (None ,O0O000OO0O0000OO0 ,'vNS','%d:%s'%(O0O000OO0O0000OO0 ,'vNS'),OOOOOO0O0000OOOOO )#line:347
        O000OOO00OOO000OO =await O0OOO0O0OO00O0OOO .server .register_namespace ('https://www.smart-factory.kr/datasolution')#line:350
        for OOO0O0OOOOO0O000O in O0OOO0O0OO00O0OOO .shells :#line:352
            O00OO000OOOOO0O0O ={}#line:353
            for OOOO00OOO000O0OO0 in OOO0O0OOOOO0O000O :#line:355
                if OOOO00OOO000O0OO0 .tag .endswith ('idShort'):#line:356
                    O00OO000OOOOO0O0O ['idShort']=OOOO00OOO000O0OO0 .text #line:357
                elif OOOO00OOO000O0OO0 .tag .endswith ('identification'):#line:358
                    O00OO000OOOOO0O0O ['identification']=OOOO00OOO000O0OO0 .text #line:359
                elif OOOO00OOO000O0OO0 .tag .endswith ('submodelRefs'):#line:360
                    await O0OOO0O0OO00O0OOO .parse_sm_refs (O00OO000OOOOO0O0O ,OOOO00OOO000O0OO0 ,OOOOOO0O0000OOOOO )#line:361
            if 'idShort'in O00OO000OOOOO0O0O and 'identification'in O00OO000OOOOO0O0O :#line:364
                O00OO000OOOOO0O0O ['ns_index']=O000OOO00OOO000OO #line:366
                O0OOO0O0OO00O0OOO .shell_info_list .append (O00OO000OOOOO0O0O )#line:367
                if OOOOOO0O0000OOOOO ==0 :#line:369
                    for O0O00O000O0OO0000 in O0OOO0O0OO00O0OOO .aas_ref_list :#line:370
                        if O0O00O000O0OO0000 ['target']==O00OO000OOOOO0O0O ['identification']:#line:371
                            O00OO000OOOOO0O0O ['idShort']='%s.%s'%(O0O00O000O0OO0000 ['parent_tag'],O00OO000OOOOO0O0O ['idShort'])#line:372
                            break #line:373
                O00OO000OOOOO0O0O ['browse_name']='%d:%s'%(O00OO000OOOOO0O0O ['ns_index'],O00OO000OOOOO0O0O ['idShort'])#line:375
                O00OO000OOOOO0O0O ['object_aas']=await O0OOO0O0OO00O0OOO .add_opcua_object (None ,O00OO000OOOOO0O0O ['ns_index'],O00OO000OOOOO0O0O ['idShort'],O00OO000OOOOO0O0O ['browse_name'],OOOOOO0O0000OOOOO )#line:376
                if 'sm_id_list'in O00OO000OOOOO0O0O :#line:380
                    for O000O00O000OO00OO in O00OO000OOOOO0O0O ['sm_id_list']:#line:381
                        O0000OO0OO0O0O00O =None #line:384
                        for OOOOOOO00OOOO00O0 in O0OOO0O0OO00O0OOO .submodels :#line:385
                            for OOOOO00O0O0000O0O in OOOOOOO00OOOO00O0 :#line:386
                                if OOOOO00O0O0000O0O .tag .endswith ('identification')and OOOOO00O0O0000O0O .text ==O000O00O000OO00OO :#line:387
                                    O0000OO0OO0O0O00O =OOOOOOO00OOOO00O0 #line:388
                                    break #line:389
                        if O0000OO0OO0O0O00O !=None :#line:392
                            O00OO0O000OO00OOO =O00OO000OOOOO0O0O ['idShort']#line:393
                            await O0OOO0O0OO00O0OOO .parse_sm (O00OO000OOOOO0O0O ['object_aas'],O00OO000OOOOO0O0O ,O0000OO0OO0O0O00O ,O00OO0O000OO00OOO ,OOOOOO0O0000OOOOO )#line:394
        if OOOOOO0O0000OOOOO ==1 :#line:399
            print ('>>> calculate references')#line:400
            for O0O00O000O0OO0000 in O0OOO0O0OO00O0OOO .aas_ref_list :#line:402
                OOOOO0000OOO0O0OO =O0O00O000O0OO0000 #line:403
                O0O0OOO0O00000000 =True #line:404
                while O0O0OOO0O00000000 ==True :#line:406
                    O0O0OOO0O00000000 =False #line:407
                    for O0OO0O0000OOO00O0 in O0OOO0O0OO00O0OOO .aas_ref_list :#line:408
                        if O0OO0O0000OOO00O0 ['target']==OOOOO0000OOO0O0OO ['aas_identification']:#line:409
                            if O0O00O000O0OO0000 ['parent_tag'].startswith (O0OO0O0000OOO00O0 ['parent_tag']):#line:410
                                O0O0OOO0O00000000 =False #line:411
                            else :#line:412
                                O0O0OOO0O00000000 =True #line:413
                                O0O00O000O0OO0000 ['parent_tag']='%s.%s'%(O0OO0O0000OOO00O0 ['parent_tag'],O0O00O000O0OO0000 ['parent_tag'])#line:414
                                OOOOO0000OOO0O0OO =O0OO0O0000OOO00O0 #line:415
                            break #line:416
                    if O0O0OOO0O00000000 ==False :#line:418
                        break #line:419
        return True #line:421
    async def convert_model (O0O00O0OOOOOO0000 ):#line:424
        print ('>>> convert_model()')#line:425
        await O0O00O0OOOOOO0000 .create_opcua_server ()#line:427
        await O0O00O0OOOOOO0000 .load_aas ()#line:428
        await O0O00O0OOOOOO0000 .parse_aas (1 )#line:430
        await O0O00O0OOOOOO0000 .parse_aas (0 )#line:431
        await O0O00O0OOOOOO0000 .export_opcua_model ()#line:432
        await O0O00O0OOOOOO0000 .write_engineering_csv ()#line:433
        return True #line:435
async def main ():#line:438
    O00O00O0O00OO00O0 =argparse .ArgumentParser ()#line:439
    O00O00O0O00OO00O0 .add_argument ('--aas')#line:440
    OO000000O0OOO000O =O00O00O0O00OO00O0 .parse_args ()#line:442
    print (OO000000O0OOO000O )#line:443
    if OO000000O0OOO000O .aas ==None :#line:445
        print ('usage: main.py [-h] [--aas AAS]')#line:446
        exit ()#line:447
    OO000O0000OOOO00O =AAS2OPCUA (OO000000O0OOO000O .aas )#line:449
    await OO000O0000OOOO00O .convert_model ()#line:450
if __name__ =='__main__':#line:452
    asyncio .run (main ())#line:456
