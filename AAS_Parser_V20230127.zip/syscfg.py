#! /usr/bin/env python3
import sys #line:5
sys .path .insert (0 ,".")#line:6
sys .path .insert (1 ,"..")#line:7
import os #line:9
import argparse #line:10
import xmlschema #line:11
import asyncio #line:12
import xmltodict #line:13
import json #line:14
import xml .etree .ElementTree as ET #line:16
from asyncua import ua ,Server #line:18
from asyncua .common .instantiate_util import instantiate #line:19
from asyncua .common .xmlexporter import XmlExporter #line:20
class AAS2OPCUA :#line:23
    def __init__ (OO00OO0000OO000O0 ,OOOO00O00OOOO00OO ):#line:24
        print ('generating syscfg.json')#line:25
        print ('>>> init()')#line:26
        OO00OO0000OO000O0 .aas_file =OOOO00O00OOOO00OO #line:28
        OO00OO0000OO000O0 .aas_schema ='AAS.xsd'#line:29
        OO00OO0000OO000O0 .end_point ='opc.tcp://0.0.0.0:4840/freeopcua/server/'#line:31
        OO00OO0000OO000O0 .doc =None #line:33
        OO00OO0000OO000O0 .root =None #line:34
        OO00OO0000OO000O0 .shells =None #line:35
        OO00OO0000OO000O0 .assets =None #line:36
        OO00OO0000OO000O0 .submodels =None #line:37
        OO00OO0000OO000O0 .descriptions =None #line:38
        OO00OO0000OO000O0 .server =None #line:40
        OO00OO0000OO000O0 .shell_info_list =[]#line:42
        OO00OO0000OO000O0 .sm_info_list =[]#line:43
        OO00OO0000OO000O0 .node_list =[]#line:44
        OO00OO0000OO000O0 .gateway_list =[]#line:46
        OO00OO0000OO000O0 .namespaces =[]#line:47
        OO00OO0000OO000O0 .cloud_list =[]#line:49
    async def create_opcua_server (OO000O0O00OO00O0O ):#line:54
        print ('>>> create_opcua_server()')#line:55
        OO000O0O00OO00O0O .server =Server ()#line:57
        await OO000O0O00OO00O0O .server .init ()#line:58
        OO000O0O00OO00O0O .server .set_endpoint (OO000O0O00OO00O0O .end_point )#line:59
        return True #line:61
    async def write_syscfg_json (O00O00OOOOOOOOO0O ):#line:64
        with open ('./generated/syscfg.json',mode ='wt',encoding ='utf-8')as OOOOOOO00OO0O0O0O :#line:65
            OOOOOOO00OO0O0O0O .write ('{\n')#line:67
            OOOOOOO00OO0O0O0O .write ('\t\"namespaces\":\n')#line:70
            OOOOOOO00OO0O0O0O .write ('\t[\n')#line:71
            O0O0000OO000OOO0O =len (O00O00OOOOOOOOO0O .namespaces )#line:73
            for OO0O0OOO000O0O000 in O00O00OOOOOOOOO0O .namespaces :#line:74
                O0O0000OO000OOO0O -=1 #line:75
                OOOOOOO00OO0O0O0O .write ('\t\t{ \"ns_index\":%d, \"ns\":\"%s\", \"aas_id\":\"%s\" }'%(OO0O0OOO000O0O000 ['ns_index'],OO0O0OOO000O0O000 ['ns_str'],OO0O0OOO000O0O000 ['aas_str']))#line:76
                if (O0O0000OO000OOO0O >0 ):#line:78
                    OOOOOOO00OO0O0O0O .write (',\n')#line:79
                else :#line:80
                    OOOOOOO00OO0O0O0O .write ('\n')#line:81
            OOOOOOO00OO0O0O0O .write ('\t],\n')#line:83
            OOOOOOO00OO0O0O0O .write ('\t\"system\":\n')#line:88
            OOOOOOO00OO0O0O0O .write ('\t[\n')#line:89
            O00O0000OOOO0O00O =len (O00O00OOOOOOOOO0O .cloud_list )#line:95
            for O0OO0O0O0OOOOO000 in O00O00OOOOOOOOO0O .cloud_list :#line:96
                O00O0000OOOO0O00O -=1 #line:97
                OOOOOOO00OO0O0O0O .write ('\t\t{\n')#line:99
                OOOOOOO00OO0O0O0O .write ('\t\t\t\"CloudName\": \"%s\",\n'%O0OO0O0O0OOOOO000 ['idShort'])#line:102
                for O00O0OO0O00OO0O0O in O0OO0O0O0OOOOO000 ['config_list']:#line:104
                    if O00O0OO0O00OO0O0O ['idShort']=='':#line:105
                        OOOOOOO00OO0O0O0O .write ('\t\t\t\"NetworkConnection\": \"%s\",\n'%O00O0OO0O00OO0O0O ['value'])#line:106
                        break #line:107
                for O00O0OO0O00OO0O0O in O0OO0O0O0OOOOO000 ['config_list']:#line:109
                    if O00O0OO0O00OO0O0O ['idShort']=='SamplingInterval':#line:110
                        OOOOOOO00OO0O0O0O .write ('\t\t\t\"SamplingInterval\": \"%s\",\n'%O00O0OO0O00OO0O0O ['value'])#line:111
                        break #line:112
            O00OOO00OOOOO0000 =len (O00O00OOOOOOOOO0O .gateway_list )#line:118
            for O0O0OO0OOO00O00O0 in O00O00OOOOOOOOO0O .gateway_list :#line:119
                O00OOO00OOOOO0000 -=1 #line:120
                OOOOOOO00OO0O0O0O .write ('\t\t{\n')#line:122
                OOOOOOO00OO0O0O0O .write ('\t\t\t\"GatewayName\": \"%s\",\n'%O0O0OO0OOO00O00O0 ['idShort'])#line:125
                for OO0O00O0O0OO0O000 in O0O0OO0OOO00O00O0 ['config_list']:#line:127
                    if OO0O00O0O0OO0O000 ['idShort']=='NetworkConnection':#line:128
                        OOOOOOO00OO0O0O0O .write ('\t\t\t\"NetworkConnection\": \"%s\",\n'%OO0O00O0O0OO0O000 ['value'])#line:129
                        break #line:130
                for OO0O00O0O0OO0O000 in O0O0OO0OOO00O00O0 ['config_list']:#line:132
                    if OO0O00O0O0OO0O000 ['idShort']=='SamplingInterval':#line:133
                        OOOOOOO00OO0O0O0O .write ('\t\t\t\"SamplingInterval\": \"%s\",\n'%OO0O00O0O0OO0O000 ['value'])#line:134
                        break #line:135
                OOOOOOO00OO0O0O0O .write ('\t\t\t\"FieldDevices\" :\n')#line:139
                OOOOOOO00OO0O0O0O .write ('\t\t\t[\n')#line:140
                O00000OOO00O00O0O =len (O0O0OO0OOO00O00O0 ['client_list'])#line:142
                for O0O00O00000000000 in O0O0OO0OOO00O00O0 ['client_list']:#line:143
                    O00000OOO00O00O0O -=1 #line:144
                    OOOOOOO00OO0O0O0O .write ('\t\t\t\t{\n')#line:147
                    OOOOOOO00OO0O0O0O .write ('\t\t\t\t\t\"DeviceName\": \"%s\",\n'%O0O00O00000000000 ['idShort'])#line:149
                    for O000O000OOOOOOOO0 in O0O00O00000000000 ['config_list']:#line:151
                        if O000O000OOOOOOOO0 ['idShort']=='NetworkConnection':#line:152
                            OOOOOOO00OO0O0O0O .write ('\t\t\t\t\t\"NetworkConnection\": \"%s\",\n'%O000O000OOOOOOOO0 ['value'])#line:153
                            break #line:154
                    for O000O000OOOOOOOO0 in O0O00O00000000000 ['config_list']:#line:156
                        if O000O000OOOOOOOO0 ['idShort']=='SamplingInterval':#line:157
                            OOOOOOO00OO0O0O0O .write ('\t\t\t\t\t\"SamplingInterval\": \"%s\"\n'%O000O000OOOOOOOO0 ['value'])#line:158
                            break #line:159
                    if O00000OOO00O00O0O >0 :#line:178
                        OOOOOOO00OO0O0O0O .write ('\t\t\t\t},\n')#line:179
                    else :#line:180
                        OOOOOOO00OO0O0O0O .write ('\t\t\t\t}\n')#line:181
                OOOOOOO00OO0O0O0O .write ('\t\t\t]\n')#line:184
                if O00OOO00OOOOO0000 >0 :#line:187
                    OOOOOOO00OO0O0O0O .write ('\t\t},\n')#line:188
                else :#line:189
                    OOOOOOO00OO0O0O0O .write ('\t\t}\n')#line:190
            OOOOOOO00OO0O0O0O .write ('\t]\n')#line:193
            OOOOOOO00OO0O0O0O .write ('}')#line:196
    async def write_gwlist_csv (OOO000O0OOO0O0000 ):#line:200
        print ('>>> write_gwlist_csv()')#line:201
        with open ('./generated/gwlist.csv',mode ='wt',encoding ='utf-8')as O000O0OOO00OO0000 :#line:203
            for OOOO0OO00O0OOOOOO in OOO000O0OOO0O0000 .gateway_list :#line:204
                O000O0OOO00OO0000 .write (OOOO0OO00O0OOOOOO ['idShort']+',')#line:205
                O000O0OOO00OO0000 .write ('ptmap_%s.csv'%OOOO0OO00O0OOOOOO ['idShort']+',')#line:206
                for OOO0OOOOOO0OO0000 in OOOO0OO00O0OOOOOO ['config_list']:#line:208
                    if OOO0OOOOOO0OO0000 ['idShort']=='NetworkConnection':#line:209
                            O000O0OOO00OO0000 .write (OOO0OOOOOO0OO0000 ['value']+',')#line:210
                            break ;#line:211
                for OOO0OOOOOO0OO0000 in OOOO0OO00O0OOOOOO ['config_list']:#line:213
                    if OOO0OOOOOO0OO0000 ['idShort']=='SamplingInterval':#line:214
                        O000O0OOO00OO0000 .write (OOO0OOOOOO0OO0000 ['value'])#line:215
                        break ;#line:216
                O000O0OOO00OO0000 .write ('\n')#line:218
    async def write_ptmaps_csv (O0O00O0O0OO00O0OO ):#line:221
        print ('>>> write_ptmaps_csv()')#line:222
        for OO0O00OO00OO0O000 in O0O00O0O0OO00O0OO .gateway_list :#line:224
            with open ('./generated/ptmap_%s.csv'%OO0O00OO00OO0O000 ['idShort'],mode ='wt',encoding ='utf-8')as O0000O0O0OO0OOO00 :#line:225
                for OOOO0O00O00OO00O0 in OO0O00OO00OO0O000 ['client_list']:#line:226
                    for OOO0OOO0000OO00OO in OOOO0O00O00OO00O0 ['pt_list']:#line:227
                        O0000O0O0OO0OOO00 .write (str (OOOO0O00O00OO00O0 ['c_index'])+',')#line:228
                        O0000O0O0OO0OOO00 .write (OOO0OOO0000OO00OO ['idShort']+',')#line:229
                        O0000O0O0OO0OOO00 .write (OOO0OOO0000OO00OO ['value']+',')#line:230
                        O0000O0O0OO0OOO00 .write (' , 50.0\n')#line:231
    async def write_clients_csv (OO0OO000OOO0O0000 ):#line:235
        print ('>>> write_clients.csv()')#line:236
        for O0000000OO0O00OO0 in OO0OO000OOO0O0000 .gateway_list :#line:238
            with open ('./generated/clients_%s.csv'%O0000000OO0O00OO0 ['idShort'],mode ='wt',encoding ='utf-8')as O000OO0OO00OO000O :#line:239
                for OO00OO0000OOO0O00 in O0000000OO0O00OO0 ['client_list']:#line:240
                    O000OO0OO00OO000O .write (str (OO00OO0000OOO0O00 ['c_index'])+',')#line:241
                    O000OO0OO00OO000O .write (O0000000OO0O00OO0 ['idShort']+',')#line:242
                    O000OO0OO00OO000O .write (OO00OO0000OOO0O00 ['idShort']+',')#line:243
                    for OOO00O0000O000000 in OO00OO0000OOO0O00 ['config_list']:#line:244
                        if OOO00O0000O000000 ['idShort']=='NetworkConnection':#line:245
                            O000OO0OO00OO000O .write (OOO00O0000O000000 ['value']+',')#line:246
                            break ;#line:247
                    for OOO00O0000O000000 in OO00OO0000OOO0O00 ['config_list']:#line:248
                        if OOO00O0000O000000 ['idShort']=='SamplingInterval':#line:249
                            O000OO0OO00OO000O .write (OOO00O0000O000000 ['value'])#line:250
                            break ;#line:251
                    O000OO0OO00OO000O .write ('\n')#line:253
    async def add_aas_namespaces (O00O0OO00OO00O000 ,O0O0OOOO00OO00O0O ,O0O00OO0O0O00OOOO ,O0O000O0OOOO000O0 ):#line:256
        O00O0OO00OOOOOO0O ={}#line:258
        O00O0OO00OOOOOO0O ['ns_index']=O0O0OOOO00OO00O0O #line:259
        O00O0OO00OOOOOO0O ['ns_str']=O0O00OO0O0O00OOOO #line:260
        O00O0OO00OOOOOO0O ['aas_str']=O0O000O0OOOO000O0 #line:261
        O00O0OO00OO00O000 .namespaces .append (O00O0OO00OOOOOO0O )#line:263
    async def add_namespaces (OO000O000O00O0OO0 ):#line:266
        print ('>>> add_namespaces()')#line:267
        for O0OO0OO00000000OO in OO000O000O00O0OO0 .shell_info_list :#line:269
            O0OO0OO00000000OO ['ns_index']=await OO000O000O00O0OO0 .server .register_namespace (O0OO0OO00000000OO ['ns_uri'])#line:270
            print ('namespace[%d] = \'ns:%s\''%(O0OO0OO00000000OO ['ns_index'],O0OO0OO00000000OO ['ns_uri']))#line:271
        return True #line:273
    async def load_aas (OOOOO000O0O0O0OOO ):#line:276
        print ('>>> load_aas(): %s'%(OOOOO000O0O0O0OOO .aas_file ))#line:277
        if not os .path .exists (OOOOO000O0O0O0OOO .aas_file ):#line:279
            print ('%s does not exist!'%(OOOOO000O0O0O0OOO .aas_file ))#line:280
            return False #line:281
        '''
        aas_xsd = xmlschema.XMLSchema(self.aas_schema)
        if aas_xsd.is_valid(self.aas_file) == False:
            print('aas[%s] has invalide schema format' % (self.aas_file))
            return False
        '''#line:288
        OOOOO000O0O0O0OOO .doc =ET .parse (OOOOO000O0O0O0OOO .aas_file )#line:290
        OOOOO000O0O0O0OOO .root =OOOOO000O0O0O0OOO .doc .getroot ()#line:291
        for OOOOO00O0OO0O00OO in OOOOO000O0O0O0OOO .root :#line:292
            if OOOOO00O0OO0O00OO .tag .endswith ('assetAdministrationShells'):#line:293
                OOOOO000O0O0O0OOO .shells =OOOOO00O0OO0O00OO #line:294
            elif OOOOO00O0OO0O00OO .tag .endswith ('assets'):#line:296
                OOOOO000O0O0O0OOO .assets =OOOOO00O0OO0O00OO #line:297
            elif OOOOO00O0OO0O00OO .tag .endswith ('submodels'):#line:299
                OOOOO000O0O0O0OOO .submodels =OOOOO00O0OO0O00OO #line:300
            elif OOOOO00O0OO0O00OO .tag .endswith ('conceptDescriptions'):#line:302
                OOOOO000O0O0O0OOO .descriptions =None #line:303
        return True #line:306
    async def parse_reference (OOOO00OOO0OO00OOO ,O000O00O000OO00O0 ,OOO0OO00O000OOOOO ,O00O0O0OOOOOO0OO0 ):#line:311
        OO0000OO00O0000OO ={}#line:312
        for O000OOOO00O00OO00 in OOO0OO00O000OOOOO :#line:313
            if O000OOOO00O00OO00 .tag .endswith ('idShort'):#line:314
                OO0000OO00O0000OO ['idShort']=O000OOOO00O00OO00 .text #line:315
        if 'idShort'in OO0000OO00O0000OO :#line:317
            print ('  reference: '+O00O0O0OOOOOO0OO0 +'.'+OO0000OO00O0000OO ['idShort'])#line:318
    async def parse_property (OOOO0000OO000000O ,OO0OOOOO00O0OO0O0 ,O0O000OO0000O0O0O ,O00OOOO00O0O00O00 ):#line:322
        O0O00O000OOOOO0OO ={}#line:323
        for OOO00OO0O000OOO00 in O0O000OO0000O0O0O :#line:324
            if OOO00OO0O000OOO00 .tag .endswith ('idShort'):#line:325
                O0O00O000OOOOO0OO ['idShort']=OOO00OO0O000OOO00 .text #line:326
            elif OOO00OO0O000OOO00 .tag .endswith ('valueType'):#line:327
                O0O00O000OOOOO0OO ['valueType']=OOO00OO0O000OOO00 .text #line:328
            elif OOO00OO0O000OOO00 .tag .endswith ('value'):#line:329
                O0O00O000OOOOO0OO ['value']=OOO00OO0O000OOO00 .text #line:330
        if 'idShort'in O0O00O000OOOOO0OO and 'valueType'in O0O00O000OOOOO0OO :#line:332
            OOO0OOO00000OO000 =OO0OOOOO00O0OO0O0 ['ns_index']#line:334
            OOO00000OOO0OOOO0 =O00OOOO00O0O00O00 +'.'+O0O00O000OOOOO0OO ['idShort']#line:335
            if OO0OOOOO00O0OO0O0 ['gwParsingLevel']==3 :#line:337
                OO00O0OO00OO0OO00 ={}#line:338
                OO00O0OO00OO0OO00 ['idShort']=O0O00O000OOOOO0OO ['idShort']#line:339
                OO00O0OO00OO0OO00 ['valueType']=O0O00O000OOOOO0OO ['valueType']#line:340
                OO00O0OO00OO0OO00 ['value']=O0O00O000OOOOO0OO ['value']#line:341
                OO0OOOOO00O0OO0O0 ['remote_client']['config_list'].append (OO00O0OO00OO0OO00 )#line:343
                print ('    - client-config: '+OO00O0OO00OO0OO00 ['idShort']+' = '+OO00O0OO00OO0OO00 ['value'])#line:344
            elif OO0OOOOO00O0OO0O0 ['gwParsingLevel']==4 :#line:346
                OOOO0OOO00OOOOO0O ={}#line:347
                OOOO0OOO00OOOOO0O ['idShort']=O0O00O000OOOOO0OO ['idShort']#line:348
                OOOO0OOO00OOOOO0O ['value']=O0O00O000OOOOO0OO ['value']#line:349
                OO0OOOOO00O0OO0O0 ['remote_client']['pt_list'].append (OOOO0OOO00OOOOO0O )#line:351
                print ('    - opcua-point: '+OOOO0OOO00OOOOO0O ['idShort']+' = '+OOOO0OOO00OOOOO0O ['value'])#line:352
            elif OO0OOOOO00O0OO0O0 ['gwParsingLevel']==5 :#line:354
                OO00O0OO00OO0OO00 ={}#line:355
                OO00O0OO00OO0OO00 ['idShort']=O0O00O000OOOOO0OO ['idShort']#line:356
                OO00O0OO00OO0OO00 ['valueType']=O0O00O000OOOOO0OO ['valueType']#line:357
                OO00O0OO00OO0OO00 ['value']=O0O00O000OOOOO0OO ['value']#line:358
                OO0OOOOO00O0OO0O0 ['edge_gw']['config_list'].append (OO00O0OO00OO0OO00 )#line:360
                print ('  - edge-config: '+OO00O0OO00OO0OO00 ['idShort']+' = '+OO00O0OO00OO0OO00 ['value'])#line:361
    async def parse_collection (O0O00O0000O0OO0O0 ,OOO00O0O00OOOO00O ,O0OO00OO0OOO00O00 ,O000000O0O0OOOO00 ):#line:367
        O0O00OOOO00OOO00O ={}#line:368
        for O00O0O0000OOO00OO in O0OO00OO0OOO00O00 :#line:369
            if O00O0O0000OOO00OO .tag .endswith ('idShort'):#line:370
                O0O00OOOO00OOO00O ['idShort']=O00O0O0000OOO00OO .text #line:371
        if 'idShort'in O0O00OOOO00OOO00O :#line:373
            O00O00O0OOO0OOOO0 =OOO00O0O00OOOO00O ['ns_index']#line:374
            OOO0OOOOOO00OOO0O =O000000O0O0OOOO00 +'.'+O0O00OOOO00OOO00O ['idShort']#line:375
            O0O0OO0O0OOOO00OO ='%d:%s'%(O00O00O0OOO0OOOO0 ,O0O00OOOO00OOO00O ['idShort'])#line:376
            if OOO00O0O00OOOO00O ['gwParsingLevel']!=5 :#line:378
                if O0O00OOOO00OOO00O ['idShort']=='BasicConfiguration':#line:379
                    OOO00O0O00OOOO00O ['gwParsingLevel']=3 #line:380
                elif O0O00OOOO00OOO00O ['idShort']=='ConnectedVariable':#line:381
                    OOO00O0O00OOOO00O ['gwParsingLevel']=4 #line:382
            for O00O0O0000OOO00OO in O0OO00OO0OOO00O00 :#line:384
                if O00O0O0000OOO00OO .tag .endswith ('value'):#line:385
                    for OO000OO0OOOO0OOO0 in O00O0O0000OOO00OO :#line:387
                        if OO000OO0OOOO0OOO0 .tag .endswith ('submodelElement'):#line:388
                            for O0O0OO0OO0O0O00OO in OO000OO0OOOO0OOO0 :#line:389
                                if O0O0OO0OO0O0O00OO .tag .endswith ('submodelElementCollection'):#line:390
                                    await O0O00O0000O0OO0O0 .parse_collection (OOO00O0O00OOOO00O ,O0O0OO0OO0O0O00OO ,OOO0OOOOOO00OOO0O )#line:391
                                elif O0O0OO0OO0O0O00OO .tag .endswith ('property'):#line:393
                                    await O0O00O0000O0OO0O0 .parse_property (OOO00O0O00OOOO00O ,O0O0OO0OO0O0O00OO ,OOO0OOOOOO00OOO0O )#line:394
                                elif O0O0OO0OO0O0O00OO .tag .endswith ('referenceElement'):#line:396
                                    await O0O00O0000O0OO0O0 .parse_reference (OOO00O0O00OOOO00O ,O0O0OO0OO0O0O00OO ,OOO0OOOOOO00OOO0O )#line:397
    async def parse_tag_from_element (O0O0OO0000OOO0000 ,O00000OO0OO0OOOOO ,O00O0O000O000OO0O ):#line:399
        for O00O0O00O0000OOOO in O00000OO0OO0OOOOO :#line:400
            if (O00O0O00O0000OOOO .tag .endswith (O00O0O000O000OO0O )):#line:401
                    return O00O0O00O0000OOOO .text #line:402
        return None #line:404
    async def parse_sm_elements (O00O0OO0OOO0000OO ,OOOO00OOOOO0O0OOO ,OO0O00OO00O0OOO0O ,OOOOO00000OO000O0 ):#line:406
        for OO000O0OO0OOO000O in OO0O00OO00O0OOO0O :#line:409
            if OO000O0OO0OOO000O .tag .endswith ('submodelElement'):#line:410
                for OOO0000O00O0O0O0O in OO000O0OO0OOO000O :#line:412
                    if OOO0000O00O0O0O0O .tag .endswith ('submodelElementCollection'):#line:413
                        OO0OOOO000O00OOOO =await O00O0OO0OOO0000OO .parse_tag_from_element (OOO0000O00O0O0O0O ,'idShort')#line:415
                        if OO0OOOO000O00OOOO ==None :#line:416
                            continue ;#line:417
                        O000O0OOOOOOOO00O =OOOO00OOOOO0O0OOO ['ns_index']#line:420
                        O0OOO0OO0000OOOOO =OOOOO00000OO000O0 +'.'+OO0OOOO000O00OOOO #line:421
                        OO0OOO00OO00OO00O ='%d:%s'%(O000O0OOOOOOOO00O ,OO0OOOO000O00OOOO )#line:422
                        O00000OO000000O00 ={}#line:424
                        O00000OO000000O00 ['idShort']=OO0OOOO000O00OOOO #line:425
                        O00000OO000000O00 ['c_index']=0 #line:426
                        O00000OO000000O00 ['client_list']=[]#line:427
                        O00000OO000000O00 ['config_list']=[]#line:428
                        O00O0OO0OOO0000OO .gateway_list .append (O00000OO000000O00 )#line:430
                        OOOO00OOOOO0O0OOO ['edge_gw']=O00000OO000000O00 #line:432
                        print ('edge-gateway: '+O00000OO000000O00 ['idShort'])#line:433
                        for OOO0O00O0O0O0OO00 in OOO0000O00O0O0O0O :#line:438
                            if OOO0O00O0O0O0OO00 .tag .endswith ('value'):#line:446
                                for OO00OOOO0O00O0O00 in OOO0O00O0O0O0OO00 :#line:447
                                    if OO00OOOO0O00O0O00 .tag .endswith ('submodelElement'):#line:449
                                        for OO0O00OO0O00O00O0 in OO00OOOO0O00O0O00 :#line:451
                                            OOO00000OOOO0000O =await O00O0OO0OOO0000OO .parse_tag_from_element (OO0O00OO0O00O00O0 ,'idShort')#line:453
                                            if OOO00000OOOO0000O ==None :#line:454
                                                continue ;#line:455
                                            if OOO00000OOOO0000O =='BasicConfiguration':#line:457
                                                OOOO00OOOOO0O0OOO ['gwParsingLevel']=5 #line:458
                                                await O00O0OO0OOO0000OO .parse_collection (OOOO00OOOOO0O0OOO ,OO0O00OO0O00O00O0 ,O0OOO0OO0000OOOOO )#line:459
                                            else :#line:461
                                                O000O0OOOOOOOO00O =OOOO00OOOOO0O0OOO ['ns_index']#line:462
                                                O0OOO0OO0000OOOOO =OOOOO00000OO000O0 +'.'+OOO00000OOOO0000O #line:463
                                                OO0OOO00OO00OO00O ='%d:%s'%(O000O0OOOOOOOO00O ,OOO00000OOOO0000O )#line:464
                                                O00OO0O000OO00OOO ={}#line:466
                                                O00OO0O000OO00OOO ['edge_gw']=OOOO00OOOOO0O0OOO ['edge_gw']#line:467
                                                O00OO0O000OO00OOO ['idShort']=OOO00000OOOO0000O #line:468
                                                O00OO0O000OO00OOO ['c_index']=OOOO00OOOOO0O0OOO ['edge_gw']['c_index']#line:469
                                                O00OO0O000OO00OOO ['config_list']=[]#line:470
                                                O00OO0O000OO00OOO ['pt_list']=[]#line:471
                                                OOOO00OOOOO0O0OOO ['edge_gw']['c_index']+=1 #line:473
                                                OOOO00OOOOO0O0OOO ['edge_gw']['client_list'].append (O00OO0O000OO00OOO )#line:474
                                                OOOO00OOOOO0O0OOO ['remote_client']=O00OO0O000OO00OOO #line:475
                                                print ('  - remote-client: '+O00OO0O000OO00OOO ['idShort'])#line:477
                                                OOOO00OOOOO0O0OOO ['gwParsingLevel']=2 #line:479
                                                await O00O0OO0OOO0000OO .parse_collection (OOOO00OOOOO0O0OOO ,OO0O00OO0O00O00O0 ,O0OOO0OO0000OOOOO )#line:480
                '''
                for sm_elem_item in sm_elem:
                    if sm_elem_item.tag.endswith('submodelElementCollection'):
                        await self.parse_collection(shell_info, sm_elem_item, parent_tag)
                    
                    elif sm_elem_item.tag.endswith('property'):
                        await self.parse_property(shell_info, sm_elem_item, parent_tag)
                    
                    elif sm_elem_item.tag.endswith('referenceElement'):
                        await self.parse_reference(shell_info, sm_elem_item, parent_tag)
                '''#line:495
    async def parse_sm (OO00O0O0OOO0O0OOO ,O000OO000OO0OOOOO ,O0O0O0000OO00000O ,OO0O0O0OOO0OOOO0O ):#line:501
        print ('>>> parse_sm()')#line:505
        OOOOO0OOO0OO0OO0O ={}#line:510
        OOOOO0OOO0OO0OO0O ['aas']=O000OO000OO0OOOOO #line:511
        for OOO0O00O00O00O0OO in O0O0O0000OO00000O :#line:513
            if OOO0O00O00O00O0OO .tag .endswith ('identification'):#line:514
                OOOOO0OOO0OO0OO0O ['identification']=OOO0O00O00O00O0OO .text #line:515
            elif OOO0O00O00O00O0OO .tag .endswith ('idShort'):#line:517
                OOOOO0OOO0OO0OO0O ['idShort']=OOO0O00O00O00O0OO .text #line:518
                OOOOO0OOO0OO0OO0O ['tagName']=O000OO000OO0OOOOO ['idShort']+'.'+OOOOO0OOO0OO0OO0O ['idShort']#line:519
        if 'identification'in OOOOO0OOO0OO0OO0O and 'idShort'in OOOOO0OOO0OO0OO0O :#line:522
            OO0OOOO000O00O00O =O000OO000OO0OOOOO ['ns_index']#line:525
            O0O00O000000O00OO =OO0O0O0OOO0OOOO0O +'.'+OOOOO0OOO0OO0OO0O ['idShort']#line:526
            OO00O0OO000OOOOOO ='%d:%s'%(OO0OOOO000O00O00O ,OOOOO0OOO0OO0OO0O ['idShort'])#line:527
            for O0OOOOO0O000O0000 in O0O0O0000OO00000O :#line:529
                if O0OOOOO0O000O0000 .tag .endswith ('submodelElements'):#line:530
                    await OO00O0O0OOO0O0OOO .parse_sm_elements (O000OO000OO0OOOOO ,O0OOOOO0O000O0000 ,O0O00O000000O00OO )#line:533
        return True #line:535
    async def parse_sm_refs (O0O0OOO0O0OO00000 ,OOOO0O0OOO0O0O0OO ,O00O000OO00O0OOO0 ):#line:542
        OOOO0O0OOO0O0O0OO ['sm_id_list']=[]#line:544
        for O00O0000OOO0000O0 in O00O000OO00O0OOO0 :#line:546
            OOOO0O0OOO0O0O0OO ['sm_list']=[]#line:547
            for OO0OOOOO00OOO0OOO in O00O0000OOO0000O0 :#line:548
                if OO0OOOOO00OOO0OOO .tag .endswith ('keys'):#line:549
                    for O0O0OO00O0000OOOO in OO0OOOOO00OOO0OOO :#line:550
                        OOOO0O0OOO0O0O0OO ['sm_id_list'].append (O0O0OO00O0000OOOO .text )#line:551
    async def parse_aas (OOO0O0O000O00000O ):#line:559
        print ('>>> parse_aas()')#line:560
        if OOO0O0O000O00000O .shells ==None :#line:562
            return False #line:563
        await OOO0O0O000O00000O .server .register_namespace ('urn:open62541.server.application')#line:566
        await OOO0O0O000O00000O .add_aas_namespaces (1 ,'urn:open62541.server.application','-')#line:567
        OOO0000O0O0O00OO0 =2 #line:570
        await OOO0O0O000O00000O .add_aas_namespaces (2 ,'https://www.smart-factory.kr/datasolution','-')#line:571
        for OO00OOOO00O0OOOOO in OOO0O0O000O00000O .shells :#line:574
            O00OO00O00000OOOO ={}#line:575
            for O0OOOO00O00O000OO in OO00OOOO00O0OOOOO :#line:577
                if O0OOOO00O00O000OO .tag .endswith ('idShort'):#line:578
                    O00OO00O00000OOOO ['idShort']=O0OOOO00O00O000OO .text #line:579
                elif O0OOOO00O00O000OO .tag .endswith ('identification'):#line:580
                    O00OO00O00000OOOO ['identification']=O0OOOO00O00O000OO .text #line:581
                elif O0OOOO00O00O000OO .tag .endswith ('submodelRefs'):#line:582
                    await OOO0O0O000O00000O .parse_sm_refs (O00OO00O00000OOOO ,O0OOOO00O00O000OO )#line:583
            if 'idShort'in O00OO00O00000OOOO and 'identification'in O00OO00O00000OOOO :#line:586
                O00OO00O00000OOOO ['ns_index']=OOO0000O0O0O00OO0 #line:588
                O00OO00O00000OOOO ['browse_name']='%d:%s'%(O00OO00O00000OOOO ['ns_index'],O00OO00O00000OOOO ['idShort'])#line:589
                if O00OO00O00000OOOO ['identification']!='http://www.aasnest.io/ids/aas/CloudDataSolution':#line:593
                    continue ;#line:594
                if 'sm_id_list'in O00OO00O00000OOOO :#line:596
                    for OO00OOO00O00O0OO0 in O00OO00O00000OOOO ['sm_id_list']:#line:600
                        if OO00OOO00O00O0OO0 !='http://www.aasnest.io/ids/sm/EdgeGWSolution':#line:604
                            continue #line:605
                        OO00OO00O00O00OOO =None #line:608
                        for O00000000O00OOOO0 in OOO0O0O000O00000O .submodels :#line:609
                            for OOOO0000OO0OOO0O0 in O00000000O00OOOO0 :#line:610
                                if OOOO0000OO0OOO0O0 .tag .endswith ('identification')and OOOO0000OO0OOO0O0 .text ==OO00OOO00O00O0OO0 :#line:611
                                    OO00OO00O00O00OOO =O00000000O00OOOO0 #line:612
                                    break #line:613
                        if OO00OO00O00O00OOO !=None :#line:616
                            O00OO00O00000OOOO ['gwParsingLevel']=0 #line:617
                            OOO0000OOO00OO0O0 =O00OO00O00000OOOO ['idShort']#line:618
                            await OOO0O0O000O00000O .parse_sm (O00OO00O00000OOOO ,OO00OO00O00O00OOO ,OOO0000OOO00OO0O0 )#line:620
        return True #line:625
    async def convert_model (OOO00O00OOO000O0O ):#line:633
        print ('>>> convert_model()')#line:634
        await OOO00O00OOO000O0O .create_opcua_server ()#line:636
        await OOO00O00OOO000O0O .load_aas ()#line:637
        await OOO00O00OOO000O0O .parse_aas ()#line:638
        await OOO00O00OOO000O0O .write_syscfg_json ()#line:642
        return True #line:643
async def main ():#line:646
    O0O0OO000OOO00OO0 =argparse .ArgumentParser ()#line:647
    O0O0OO000OOO00OO0 .add_argument ('--aas')#line:648
    OOOO0OOO00000O00O =O0O0OO000OOO00OO0 .parse_args ()#line:650
    print (OOOO0OOO00000O00O )#line:651
    if OOOO0OOO00000O00O .aas ==None :#line:653
        print ('usage: main.py [-h] [--aas AAS]')#line:654
        exit ()#line:655
    OOO00OOO000000OOO =AAS2OPCUA (OOOO0OOO00000O00O .aas )#line:657
    await OOO00OOO000000OOO .convert_model ()#line:658
if __name__ =='__main__':#line:660
    asyncio .run (main ())#line:661
